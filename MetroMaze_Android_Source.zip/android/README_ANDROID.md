# Metro Maze para Android

Proyecto Android nativo que empaqueta el juego como una aplicación sin conexión.

- Paquete: `com.paizflores.metromaze`
- Mínimo: Android 6.0 (API 23)
- Permisos solicitados: ninguno
- Salida de compilación: `app/build/outputs/apk/debug/app-debug.apk`
