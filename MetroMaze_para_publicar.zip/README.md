# Metro Maze: Rescue Circuit

Juego de laberinto original de cinco niveles. Abre `index.html` en un navegador o publica toda esta carpeta como sitio estático.

## Controles

- Teclado: flechas o WASD para moverse; Espacio o B para colocar una pulso-carga.
- Celular: botones direccionales y botón **PULSO** en pantalla.

## Publicación solicitada por la evaluación

1. Comprime el contenido de esta carpeta en un archivo ZIP.
2. Entra a [Tiiny Host](https://tiiny.host/), carga el ZIP y copia la URL pública que genere.
3. Abre [WebIntoApp](https://www.webintoapp.com/app-maker), pega la URL de Tiiny Host, selecciona Android y descarga el APK generado.
4. En el teléfono, permite temporalmente la instalación desde el navegador o gestor de archivos que descargó el APK y confirma la instalación.

> Para cambiar el juego, edita `game.js` o `styles.css`, vuelve a comprimir y publica de nuevo. No se requieren permisos especiales de Android: el juego funciona sin cámara, ubicación, contactos ni almacenamiento.
